module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN || '8767897683:AAFCqkq81b0j14bfmkmYvXMxE7UjlmuMHNk',
  startupPassword: process.env.BOT_PASSWORD || 'nexa'
};
