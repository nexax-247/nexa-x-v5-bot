const fs = require('fs')

global.owner = "𝟵𝟮𝟯𝟬𝟳𝟴𝟬𝟳𝟭𝟵𝟴𝟮" //owner number
global.footer = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷" //footer section
global.status = false //"self/public" section of the bot
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['𝟵𝟮𝟯𝟬𝟳𝟴𝟬𝟳𝟭𝟵𝟴𝟮']
global.xprefix = '.'
global.gambar = "https://o.uguu.se/iRcJMsdi.jpg"
global.OWNER_NAME = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷" //
global.DEVELOPER = ["𝟵𝟮𝟯𝟬𝟳𝟴𝟬𝟳𝟭𝟵𝟴𝟮"] //
global.BOT_NAME = "𝐍𝐄𝐗𝐀 𝐕𝟓"
global.bankowner = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.creatorName = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.ownernumber = '𝟵𝟮𝟯𝟬𝟳𝟴𝟬𝟳𝟭𝟵𝟴𝟮'  //creator number
global.location = "NEXA TECH HQ"
global.prefa = ['','!','.','#','&']
//================DO NOT CHANGE OR YOU'LL GET AN ERROR=============\
global.footer = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷" //footer section
global.link = "https://chat.whatsapp.com/EGomptrlDXVD9tV85etFf3?mode=gi_t"
global.autobio = false//auto update bio
global.botName = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.version = "5.0.0"
global.botname = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.author = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.themeemoji = "🥷"
global.wagc = 'https://chat.whatsapp.com/EGomptrlDXVD9tV85etFf3?mode=gi_t'
global.thumbnail = 'https://ibb.co/DD95vPBv'
global.richpp = ' '
global.packname = "Sticker By 𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.author = "𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷"
global.creator = "𝟵𝟮𝟯𝟬𝟳𝟴𝟬𝟳𝟭𝟵𝟴𝟮@s.whatsapp.net"
global.ownername = 'Great ' 
global.onlyowner = `Only 𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷 can use this Command 🥶🥷`
  // reply 
global.database = `*To Exist In The Database Contact The Owner of this bot*`
  global.mess = {
wait: "*Configurating.......*",
   success: "*Successfully acknowledged ☑️*",
   on: "*Activated ✅*", 
   prem: "*Feature For Premium Users only*", 
   off: "*Deactivated 📛*",
   query: {
       text: "*Please, Provide A Text Query 📑*",
       link: "Please, provide a valid link 🔗*",
   },
   error: {
       fitur: "*Status 🌐: Feature Or Command error ❌*",
   },
   only: {
       group: "*Group only feature ❌*",
private: "*Private chat feature only ❌*",
       owner: "*Owner feature only ❌*",
       admin: "*bot owner feature only ❌*",
       badmin: "*Seek admin privilege's to use this command ❌*",
       premium: "*Availabe for premium users only ❌*",
   }
}

global.hituet = 0
//false=disable and true=enable
global.autoviewstatus = true
global.autoread = true //auto read messages
global.autobio = true //auto update bio
global.anti92 = false //auto block +92 
global.autoswview = true //auto view status/story

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})

//Property of  𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷
//owner number:+𝟵𝟮𝟯𝟬𝟳𝟴𝟬𝟳𝟭𝟵𝟴𝟮
//telegram :𝙽𝙴𝚇𝙰 𝚃𝙴𝙲𝙷

